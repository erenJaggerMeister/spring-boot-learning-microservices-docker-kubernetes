package cmd

import (
	"context"
	"fmt"

	"github.com/spf13/cobra"

	"github.com/hookdeck/hookdeck-cli/pkg/validators"
)

type connectionPauseCmd struct {
	cmd *cobra.Command
}

func newConnectionPauseCmd() *connectionPauseCmd {
	cc := &connectionPauseCmd{}

	cc.cmd = &cobra.Command{
		Use:   "pause <connection-id-or-name>",
		Args:  validators.ExactArgs(1),
		Short: "Pause a connection temporarily",
		Long: `Pause a connection temporarily.

The connection will queue incoming events until unpaused.

Examples:
	 # Pause by connection ID
	 hookdeck gateway connection pause web_abc123

	 # Pause by connection name
	 hookdeck gateway connection pause my-connection`,
		RunE: cc.runConnectionPauseCmd,
	}
	cc.cmd.Annotations = map[string]string{
		"cli.arguments": `[{"name":"connection-id-or-name","type":"string","description":"Connection ID or name","required":true}]`,
	}

	return cc
}

func (cc *connectionPauseCmd) runConnectionPauseCmd(cmd *cobra.Command, args []string) error {
	if err := Config.Profile.ValidateAPIKey(); err != nil {
		return err
	}

	client := Config.GetAPIClient()
	ctx := context.Background()

	id, err := resolveConnectionID(ctx, client, args[0])
	if err != nil {
		return err
	}

	conn, err := client.PauseConnection(ctx, id)
	if err != nil {
		return fmt.Errorf("failed to pause connection: %w", err)
	}

	name := "unnamed"
	if conn.Name != nil {
		name = *conn.Name
	}

	fmt.Printf(SuccessCheck+" Connection paused: %s (%s)\n", name, conn.ID)
	return nil
}
